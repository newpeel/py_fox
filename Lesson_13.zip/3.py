nums = [54, 14, 136, 19, 2]
state = True

# в данном примере
#    1-я позиция "nums" -> parameter_1
#    2-я позиция "state" -> parameter_2
def test_params(parameter_1, parameter_2):
    pass

# равнозначные варианты вызова функции
test_params(nums, state)
test_params([54, 14, 136, 19, 2], True)
