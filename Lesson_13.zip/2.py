def number():
   for i in range(4):
      print(i)
number()