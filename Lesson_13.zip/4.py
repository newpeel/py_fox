def print_trio(a, b, c):
    print(a, b, c)


print_trio(a=7, b=8, c=9)
