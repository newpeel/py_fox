print("Приветствую нового игрока!")
player_name = input("Введите ваше имя, чтобы сыграть в нашу викторину")

print("Правила игры:")
print("* Ведущий задает вопрос")
print("* У игрока 3 попытки правильно ответить на него")
print("* Ответ вводится маленькими буквами")

yes = input(f"{player_name}, готовы сыграть? Да/Нет")

if yes == "Да" or yes == "да":
    count_try = 3
    question = "В каком году открыли первую в России станцию метро?"
    print(question)
    right_answer = "1935"
    player_answer = input("Ваш ответ: ")
    count_try = count_try - 1
    while player_number != right_answer and count_try > 0:
        print("Попробуй еще раз!")
        print(f"Количество потраченных попыток: {3 - count_try}")

        player_answer = input("Ваш ответ: ")
        count_try = count_try - 1

    if player_answer == right_answer:
        print("Поздравляю с победой!")
        print(f"Количество потраченных попыток: {3 - count_try}")
    else:
        print("Не повезло! Но в следующий раз обязательно повезет!")

else:
    print("Можете попробовать в следующий раз!")