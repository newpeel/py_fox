def program(a, b, c):
   a = a + b * c
   print(a)
program(2,2,2)
