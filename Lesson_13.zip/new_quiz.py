count_try = 3

rules = [
    "Ведущий задает вопрос",
    f"У игрока {count_try} попытки",
    "Ответ вводится маленькими буквами"
]

question_list = [
    "В каком году открыли первую в России станцию метро?",
    "Сколько дней в ноябре?",
    "Во сколько лет умер Пушкин?",
    "капибара самый большой кто?",
    "Когда Рождество в Америке?",
    "В каком году снят первый фильм 'Гарри Поттер?",
    "Кто такой Багги?",
    "В каком фильме была сказана фраза: 'Детям цветы, жене мороженое'?"
]

answer_list = [
    "1935",
    "30",
    "37",
    "грызун",
    "25 декабря",
    "2001",
    "клоун",
    "бриллиантовая рука"
]

def print_rules(rules):
    print('Правила игры')
    for rule in rules:
        print(f"*{rule}")


def ask_question(question, right_answer, count_try):
    print(question)
    player_answer = input("Ваш ответ: ")
    count_try -= 1
    while player_answer != right_answer and count_try > 0:
        print("Попробуй еще раз!")
        print(f"Количество потраченных попыток: {3 - count_try}")
        player_answer = input("Ваш ответ: ")
        count_try -= 1
    if player_answer == right_answer:
        print("Поздравляю с победой!")
        print(f"Количество потраченных попыток: {3 - count_try}")
    else:
        print("Не повезло! Но в следующий раз обязательно повезет!")


def game(rules, question_list, answer_list, count_try):
    print_rules(rules)
    for i in range(len(question_list)):
        ask_question(question_list[i], answer_list[i], count_try)
    print("Поздравляю с завершением викторины")


game(rules, question_list, answer_list, count_try)
