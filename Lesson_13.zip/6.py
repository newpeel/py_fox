num = 56

def some_function(n):
    n = n + 10
    print(n)

some_function(num)
print(num)
