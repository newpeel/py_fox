
def max_number(a, b):
    if a > b:
        print(f'число {a} больше {b}')
    else:
        print(f'число {b} больше {a}')

max_number(0, -10)
max_number(33, 100)

