def add(a, b, c):
    return print(a + b - c)


add(86, 42, 33)

