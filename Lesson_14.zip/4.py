def sort(nums):
    for i in range(len(nums) - 1):
        for j in range(len(nums) - 1 - i):
            if nums[j] > nums[j + 1]:
                nums[j], nums[j + 1] = nums[j + 1], nums[j]
    return nums

my_list = [64, 34, 25, 12, 22, 11, 90]
sorted_list = sort(my_list)
print(sorted_list)
