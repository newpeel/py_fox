from datetime import datetime
import time

start = datetime.now()
# здесь вызываем функцию
def calculate():
   print(1)

calculate()
print(datetime.now() - start)
