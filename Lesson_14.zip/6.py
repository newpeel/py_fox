# Глобальное пространство имен
global_var = 10

def example_function(global_var):
    # Локальное пространство имен для функции
    local_var = 5
    global_var = global_var + 100
    print("Локальная переменная local_var внутри функции:", local_var)
    print("Глобальная переменная global_var внутри функции:", global_var)

example_function(global_var)

print("Глобальная переменная global_var вне функции:", global_var)

# Встроенное пространство имен
print("Использование встроенной функции len:", len([1, 2, 3]))
