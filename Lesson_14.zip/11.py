def recursive(value):
    print(value)
    recursive(value+1)
recursive(1)
