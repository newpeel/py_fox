def outer_function(x):
    def middle_function(y):
        print("Первая вложенная функция начала выполнение")

        def inner_function(z):
            return z * 2

        result = inner_function(y)
        print(f"Вторая вложенная функция: {result}")
        print("Первая вложенная функция завершила выполнение")


middle_result = middle_function(x)
print(f"Результат первой вложенной функции: {middle_result}")
print("Внешняя функция завершила выполнение")

outer_function(5)
