def read_from_db():


# ...

def operate_with_data():


# ...

def print_result():


# ...

def write_to_db():


# ...

read_from_db()
operate_with_data()
print_result()
write_to_db()