def print_receipt(price, cost, count):
    print()
    print(f"Магазин {store_name}")
    print("КАССОВЫЙ ЧЕК")
    print("=====================")
    for product in products:
        print(f"{product} --------- {count} шт.    {price}")
    print(f"ИТОГО: {cost} руб.")
    print()

def add_product():
    product = input("Введите название продукта(чтобы завершить введите чек): ")
    count = input("Введите количество продукта(чтобы завершить введите чек): ")
    while product != "чек":
        products.append(product)
        print(f"{product} добавлен в корзину! {count} шт.")
        product = input("Введите название продукта(чтобы завершить введите чек): ")

def welcome():
    print("Приветствую покупатель!")


store_name = "Все по 99"
price = 99
count = 0


while True:
    products = []
    welcome()
    user_answer = input("Готов начать обслуживание?")
    add_product()
    cost = price * count * len(products)
    print_receipt(price, cost)
