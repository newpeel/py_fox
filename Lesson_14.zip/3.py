def speed(distance, time):
    return distance / time