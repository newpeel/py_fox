def calculate(num1, num2):
    add = num1 + num2
    sub = num1 - num2
    return add, sub


num1 = 42
num2 = 728
res1, res2, res3 = calculate(num1, num2)


print("Результат:", res1, res2, res3)
print("Тип результата:", type((res1, res2, res3)))
