info = [2, 5, 3, 1, 4, 3, 1, 5, 5, 5, 1]  # список оценок

print(f"Список оценок:{info}")


def add_grade(score):  # добавить оценку
    info.append(score)


def how_many(number):  # сколько оценок указанного типа через алгоритм
    amount = 0
    for i in info:
        if i == number:
            amount += 1
    return amount


def how_many_ez(number):  # сколько оценок указанного типа через count
    return info.count(number)


# temp = info.count(number)
#	return temp тоже может работать


def average():  # средняя оценка
    temp = round(sum(info) / len(info), 2)
    return temp


answer = 0

while answer != 99:
    print(
        'Введите номер команды:\n1 - добавить оценку\n2 - сколько оценок 1.0 \n3 - сколько оценок 2.0\n4 - Среднее значение\n99 - Завершить работу')
    answer = int(input())
    number = 0

    if answer == 1:
        print('Введите оценку')
        number = int(input())
        add_grade(number)
        print(f"Список оценок:{info}")

    elif answer == 2:
        print('Введите оценку')
        number = int(input())
        print(f"Количество {number}:{how_many(number)}")

    elif answer == 3:
        print('Введите оценку')
        number = int(input())
        print(f"Количество {number}:{how_many_ez(number)}")

    elif answer == 4:
        print(f"Средняя оценка:{average()}")

    else:
        print('Ошибка!')

    print('\n' * 2)

print('Спасибо что использовали Школьный помощник 1.0')
