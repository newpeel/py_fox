from my_module import hello_fox as hf

hf()


