import time


for i in range(4):
    time.sleep(1)
    print(i)
