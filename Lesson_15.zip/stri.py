import string

print(string.digits)
print(string.ascii_letters)
print(string.punctuation)
print(string.ascii_uppercase)
print(string.hexdigits)
print(string.ascii_lowercase)
