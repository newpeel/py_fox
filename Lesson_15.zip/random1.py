import random


random_number = random.randint(1, 100)
print(random_number)

random_float = random.random()
print(random_float)

random_float = random.uniform(1, 10)
print(random_float)
