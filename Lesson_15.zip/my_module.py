
def hello_fox():
    print("Привет, Фоксфорд!")


def numbers():
    for i in range(10):
        print(i)
