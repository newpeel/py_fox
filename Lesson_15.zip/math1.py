from math import *

print(pi)


res = radians(30)  # конвертируем градусы в радианы

print(sin(res))
print(cos(res))
print(tan(res))

print(e)

print(ceil(5.1))

print(floor(6.999999999999999))

print(modf(5.2))

