

f = open('test.txt', 'w')  # открытие в режиме записи
f.write('123sdfsdfaasdfasdfsasdf')  # запись Hello World в файл
f.close()  # закрытие файла
