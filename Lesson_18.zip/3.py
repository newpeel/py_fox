text = [
  'Александр\n',
  'Хорошо\n',
  '5\n']
fp = open('text2.txt', 'w', encoding='utf-8')
fp.writelines(text)
fp.close()


def replace_line(file_name, line_num, text):
  lines = open(file_name, 'r').readlines()
  lines[line_num] = text
  out = open(file_name, 'w')
  out.writelines(lines)
  out.close()


replace_line('text2.txt', 2, '4')
