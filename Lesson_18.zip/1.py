
f = open('text.txt', 'r')
print(f.readline())  
print(f.readline(2))
print(f.readlines())