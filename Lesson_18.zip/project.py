import telebot

token = '6706497732:AAF3gVQ58t-COXOeStmxo8DqvBF_OERtEyk'

bot = telebot.TeleBot(token)


@bot.message_handler(commands=['start', 'help'])
def helper(message):
    bot.send_message(message.chat.id,
                     '/add - добавить дело \n' + 
                     '/check - проверить список дел \n' +
                     '/remove - удалить выполненное дело \n')


@bot.message_handler(commands=['add'])
def add_th(message):
    sent1 = bot.send_message(message.chat.id, 'Что добавить?')
    bot.register_next_step_handler(sent1, add_rep)


def add_rep(message):
    a = str(message.from_user.id) + ".txt"
    with open(a, 'a', encoding='utf-8') as file:
        file.write(str(message.text) + '\n')
    bot.send_message(message.chat.id, str(message.text) + ' добавлено')


@bot.message_handler(commands=['check'])
def check_th(message):
    sent2 = bot.send_message(message.chat.id, 'Список дел')
    a = str(message.from_user.id) + ".txt"
    lines = open(a, 'r', encoding='utf-8').readlines()
    b = ''
    for i in lines:
        b = b + str(lines.index(i)) + ' ' + i + '\n'
    bot.send_message(message.chat.id, str(b))


@bot.message_handler(commands=['remove'])
def remove_th(message):
    sent3 = bot.send_message(message.chat.id, 'Введите номер строки для удаления')
    bot.register_next_step_handler(sent3, remove_rep)


def remove_rep(message):
    a = str(message.from_user.id) + ".txt"
    replace_line(a, int(message.text) - 1, '')
    bot.send_message(message.chat.id, str(message.text) + ' удалено')


def replace_line(file_name, line_num, text):
    lines = open(file_name, 'r').readlines()
    lines[line_num] = text
    out = open(file_name, 'w')
    out.writelines(lines)
    out.close()


bot.polling(none_stop=True,
            interval=0)  # Она скажет программе, чтобы она непрерывно спрашивала у бота, не пришли ли ему какие-то новые сообщения