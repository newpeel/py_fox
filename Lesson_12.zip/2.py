for i in range(1, 4):
    for j in range(1, 6):
        print(f"i = {i}, j = {j}", end=' ')
    print()
