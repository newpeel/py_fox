from random import randint


def get_cows_bulls(first_number, second_number):
    cows = 0
    bulls = 0
    for i in range(len(first_number)):
        if first_number[i] == second_number[i]:
            bulls += 1
        elif first_number[i] in second_number:
            cows += 1
    return cows, bulls


def get_table_info(player_number: str, bulls: int, cows: int) -> str:
    return f"""
Ваше число | Быки | Коровы
{player_number}{(11 - len(player_number)) * " "}| {bulls}    | {cows}
    """


def start_game():
    user_input = input("Для старта игры нажми клавишу Enter")
    while user_input != "стоп":
        hidden_number = str(randint(100, 999))
        # print(hidden_number)
        print(f"Компьтер загадал {len(hidden_number)}-х значное число. Попробуй его отгадать")
        user_input = input("Введи число: ")
        while user_input != hidden_number:
            cows, bulls = get_cows_bulls(user_input, hidden_number)
            print(get_table_info(user_input, bulls, cows))
            user_input = input("Введи число: ")
        print("Поздравляю! Ты отгадал!")
        user_input = input("Чтобы закончить игру введи слово - стоп, для продолжения нажми клавишу  Enter: ")


start_game()
