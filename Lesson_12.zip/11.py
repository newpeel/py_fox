a = 4
b = 0
while a > 0:
    b = b + a * 2
    a = a - 1
print(b)
