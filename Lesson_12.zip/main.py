for i in range(2023, 2035):
    for j in range(1, 13):
        for k in range(1, 31):
            print(i, j, k, end=" ")
        print()
    print()
