number_player1 = input("Игрок 1, загадайте число: ")

# Проверим, что введено трёхзначное число
while not number_player1.isdigit() or len(number_player1) != 3:
    print("Пожалуйста, введите трёхзначное число.")
    number_player1 = input("Игрок 1, загадайте число: ")

number_player2 = input("Введите число: ")

while number_player2 != number_player1:
    cows = 0
    bulls = 0
    for i in range(3):
        for k in range(3):
            if number_player1[i] == number_player2[k]:
                if i == k:
                    bulls += 1
                else:
                    cows += 1
    print("Ваше число | Быки | Коровы")
    print(f"{number_player2}        | {bulls}    | {cows}")
    number_player2 = input("Введите число: ")

print("Игрок 2, ты отгадал число, теперь твоя очередь загадывать число")
number_player2 = input("Игрок 2, загадайте число: ")

# Проверим, что введено трёхзначное число
while not number_player2.isdigit() or len(number_player2) != 3:
    print("Пожалуйста, введите трёхзначное число.")
    number_player2 = input("Игрок 2, загадайте число: ")

number_player1 = input("Введите число: ")

while number_player1 != number_player2:
    cows = 0
    bulls = 0
    for i in range(3):
        for k in range(3):
            if number_player2[i] == number_player1[k]:
                if i == k:
                    bulls += 1
                else:
                    cows += 1
    print("Ваше число | Быки | Коровы")
    print(f"{number_player1}        | {bulls}    | {cows}")
    number_player1 = input("Введите число: ")
