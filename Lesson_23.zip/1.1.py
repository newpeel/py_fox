from discord.ext import commands
import discord

intents = discord.Intents().all()
bot = commands.Bot(command_prefix='$', intents=intents)


@bot.event
async def on_ready():
    print('Бот {0.user} включился '.format(bot))


@bot.event
async def on_message(message):
    if message.author == bot.user:
        return

    await message.channel.send(message.content)


@bot.command(name='echo')
async def _echo(ctx, arg):
    await ctx.message.channel.send(arg)



bot.run('token')
