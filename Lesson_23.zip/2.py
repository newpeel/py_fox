from discord.ext import commands
import discord
import random

intents = discord.Intents().all()
bot = commands.Bot(command_prefix='$', intents=intents)

trigger = ["грустно", "печально", "одиноко"]
emodji = ['\U0001F604', '\U0001F642', '\U0001F609', '\U0001F438']


@bot.event
async def on_message(message):
    msg = message.content
    if any(word in msg for word in trigger):
        await message.channel.send('Все будет хорошо! ' + random.choice(emodji))


bot.run('token')
