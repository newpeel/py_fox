import requests
import json
arg = 2
#print('list' * arg)
response = requests.get("https://pokeapi.co/api/v2/pokemon/43/")
#print('response ', response.text)


r = response.json()
print('name: ', r['name'])
print('base_experience: ', r['base_experience'])
print('order: ', r['order'])
print('height: ', r['height'])
print('weight: ', r['weight'])

abilities = r.get("abilities")
for i in range(len(abilities)):
    ab1 = abilities[i]
    print(f'Способность {i}: ', ab1['ability']['name'])

forms = r.get("forms")
for i in range(len(forms)):
    fr1 = forms[i]
    print(f'Форма {i}: ', fr1['name'])

stats = r.get("stats")
for i in range(len(stats)):
    fr1 = stats[i]
    print(fr1['stat']['name'], ' = ', fr1['base_stat'])
