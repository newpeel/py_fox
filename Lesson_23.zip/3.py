import requests, json
from discord.ext import commands
import discord

intents = discord.Intents().all()
bot = commands.Bot(command_prefix='$', intents=intents)


@bot.event
async def on_ready():
    print('Бот {0.user} включился '.format(bot))


@bot.command()
async def age(ctx):
    input_name = str(ctx.author.name)
    response = requests.get("https://api.agify.io/?name=" + input_name[0:5])
    json_data = json.loads(response.text)
    print(json_data)
    age = json_data['age']
    await ctx.channel.send('Твой возраст: ' + str(age))


bot.run('token')
