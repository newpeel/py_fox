import telebot
from telebot import types

token = '6706497732:AAF3gVQ58t-COXOeStmxo8DqvBF_OERtEyk'
bot = telebot.TeleBot(token)


@bot.message_handler(commands=["start", "help"])  # приветствие и старт работы
def welcome(message):
    main_menu = types.InlineKeyboardMarkup()
    main_menu.row_width = 1
    main_menu.add(types.InlineKeyboardButton(text='\U0001F60E Активировать предмет', callback_data='activate_subject'))
    bot.send_message(message.chat.id, text="Активируй предмет перед добавлением оценок")
    bot.send_message(message.chat.id, text=" \U0001F4DC Дневник " + message.from_user.first_name + "\U0001F499",
                     reply_markup=main_menu)


@bot.callback_query_handler(func=lambda call: True)  # очередь сообщений и очередь callback
def query_handler(call):
    if call.data == 'main_menu':
        main_menu = types.InlineKeyboardMarkup()
        main_menu.row_width = 1
        main_menu.add(types.InlineKeyboardButton(text='\U00002705 Выбрать предмет ', callback_data='choose_subject'))
        main_menu.add(
            types.InlineKeyboardButton(text='\U00002728 Активировать мой предмет', callback_data='activate_subject'))
        bot.send_message(call.message.chat.id, text=" \U0001F4DC Дневник " + call.from_user.first_name + "\U0001F499",
                         reply_markup=main_menu)
        bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id,
                                      reply_markup=None)  # удаляем кнопки после ответа
        bot.answer_callback_query(call.id, text="")

    elif call.data == 'activate_subject':
        ac_menu = types.InlineKeyboardMarkup()
        ac_menu.add(types.InlineKeyboardButton(text='\U0001F5A5 Информатика', callback_data='informatics_activate'))
        ac_menu.add(types.InlineKeyboardButton(text='Математика', callback_data='-1'))
        ac_menu.add(types.InlineKeyboardButton(text='Русский язык', callback_data='russian_act'))# задел на будущее
        ac_menu.add(types.InlineKeyboardButton(text='\U0001F519 Назад', callback_data='main_menu'))
        bot.send_message(call.message.chat.id, 'Предметы', reply_markup=ac_menu)
        bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id,
                                      reply_markup=None)  # удаляем кнопки после ответа
        bot.answer_callback_query(call.id, text="")


    elif call.data == 'informatics_activate':
        with open(str(call.from_user.id) + '_subject_choice' + '.txt', 'w', encoding='UTF-8') as f_m:
            f_m.write('informatics')
        with open(str(call.from_user.id) + '_subject_choice' + '.txt', 'r', encoding='UTF-8') as f_m:
            subject_name = f_m.read().split('\n')
        with open(str(call.from_user.id) + '_' + str(subject_name[0]) + '.txt', 'w+', encoding='UTF-8') as f_m:
            pass
        ac_inf_menu = types.InlineKeyboardMarkup()
        ac_inf_menu.add(types.InlineKeyboardButton(text='\U0001F519 Назад', callback_data='main_menu'))
        bot.send_message(call.message.chat.id, '\U0001F973 Информатика активирована', reply_markup=ac_inf_menu)
        bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id,
                                      reply_markup=None)  # удаляем кнопки после ответа
        bot.answer_callback_query(call.id, text="")

    elif call.data == 'choose_subject':
        ch_menu = types.InlineKeyboardMarkup()
        ch_menu.add(types.InlineKeyboardButton(text='\U0001F5A5 Информатика', callback_data='informatics'))
        ch_menu.add(types.InlineKeyboardButton(text='Другой предмет', callback_data='-1'))  # задел на будущее
        ch_menu.add(types.InlineKeyboardButton(text='\U0001F519 Назад', callback_data='main_menu'))
        bot.send_message(call.message.chat.id, 'Предметы', reply_markup=ch_menu)
        bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id,
                                      reply_markup=None)  # удаляем кнопки после ответа
        bot.answer_callback_query(call.id, text="")


    elif call.data == 'informatics':
        with open(str(call.from_user.id) + '_subject_choice' + '.txt', 'w', encoding='UTF-8') as f_m:
            f_m.write('informatics')

        with open(str(call.from_user.id) + '_subject_choice' + '.txt', 'r', encoding='UTF-8') as f_m:
            subject_name = f_m.read().split('\n')
        inf_menu = types.InlineKeyboardMarkup()
        inf_menu.row_width = 2
        inf_menu.add(types.InlineKeyboardButton("\U0001F50E	Проверить ", callback_data="check_scores"),
                     types.InlineKeyboardButton("\U0001F4CE Добавить ", callback_data="add_score_ch"))
        inf_menu.add(types.InlineKeyboardButton("\U0001F519 Назад ", callback_data="choose_subject"))
        bot.send_message(call.message.chat.id, 'Информатика', reply_markup=inf_menu)
        bot.answer_callback_query(call.id, text="")  # Без нее будут часы, нужно отреагировать на колбек
        bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id,
                                      reply_markup=None)  # удаляем кнопки после ответа

    elif call.data == 'check_scores':
        with open(str(call.from_user.id) + '_subject_choice' + '.txt', 'r', encoding='UTF-8') as f_m:
            subject_name = f_m.read().split('\n')

        if subject_name[0] == 'informatics':  # check оценок
            print('filename v check', str(call.from_user.id) + '_' + str(subject_name[0]) + '.txt')
            with open(str(call.from_user.id) + '_' + str(subject_name[0]) + '.txt', 'r', encoding='UTF-8') as f_m:
                informatics = f_m.readlines()
            answer = ''
            for i in informatics:
                answer += ' ' + i
            inf_check = types.InlineKeyboardMarkup()
            inf_check.add(types.InlineKeyboardButton(text='\U0001F519 Назад', callback_data='informatics'))
            bot.send_message(call.message.chat.id, 'Список оценок:\n' + answer, reply_markup=inf_check)
            bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id,
                                          reply_markup=None)  # удаляем кнопки после ответа
            bot.answer_callback_query(call.id, text="")


    elif call.data == 'add_score_ch':  # выбор оценки и удаления
        with open(str(call.from_user.id) + '_subject_choice' + '.txt', 'r', encoding='UTF-8') as f_m:
            subject_name = f_m.read().split('\n')
        if subject_name[0] == 'informatics':
            add_score_ch_menu = types.InlineKeyboardMarkup()
            add_score_ch_menu.row_width = 5
            add_score_ch_menu.add(types.InlineKeyboardButton("1", callback_data=1),
                                  types.InlineKeyboardButton("2", callback_data=2),
                                  types.InlineKeyboardButton("3", callback_data=3),
                                  types.InlineKeyboardButton("4", callback_data=4),
                                  types.InlineKeyboardButton("5", callback_data=5))
            add_score_ch_menu.add(types.InlineKeyboardButton(text='\U0001F519 Назад', callback_data='informatics'),
                                  types.InlineKeyboardButton("\U00002702 Удалить", callback_data='remove_score'))
            bot.send_message(call.message.chat.id, 'Информатика', reply_markup=add_score_ch_menu)
            bot.answer_callback_query(call.id, text="")
            bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id,
                                          reply_markup=None)  # удаляем кнопки после ответа



    elif call.data == 'remove_score':
        with open(str(call.from_user.id) + '_subject_choice' + '.txt', 'r', encoding='UTF-8') as f_m:
            subject_name = f_m.read().split('\n')

        if subject_name[0] == 'informatics':  # удаление оценок
            inf_rem = types.InlineKeyboardMarkup()
            inf_rem.add(types.InlineKeyboardButton(text='\U0001F519 Назад', callback_data='add_score_ch'))

            with open(str(call.from_user.id) + '_' + str(subject_name[0]) + '.txt', 'r', encoding='UTF-8') as f_m:
                informatics = f_m.readlines()

            del informatics[-1]

            with open(str(call.from_user.id) + '_' + str(subject_name[0]) + '.txt', 'w', encoding='UTF-8') as f_m:
                f_m.writelines(informatics)

            bot.answer_callback_query(call.id, text="Оценка удалена")

            with open(str(call.from_user.id) + '_' + str(subject_name[0]) + '.txt', 'r', encoding='UTF-8') as f_m:
                informatics = f_m.readlines()

            answer = ''
            for i in informatics:
                answer += ' ' + i

            bot.send_message(call.message.chat.id, 'Список оценок:\n' + answer, reply_markup=inf_rem)
            bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id,
                                          reply_markup=None)  # удаляем кнопки после ответа


    elif int(call.data) > 0:
        with open(str(call.from_user.id) + '_subject_choice' + '.txt', 'r', encoding='UTF-8') as f_m:
            subject_name = f_m.read().split('\n')

        if subject_name[0] == 'informatics':  # Добавление оценок
            with open(str(call.from_user.id) + '_' + str(subject_name[0]) + '.txt', 'r', encoding='UTF-8') as f_m:
                informatics = f_m.readlines()

            informatics.append(call.data + "\n")

            with open(str(call.from_user.id) + '_' + str(subject_name[0]) + '.txt', 'w', encoding='UTF-8') as f_m:
                f_m.writelines(informatics)

            bot.answer_callback_query(call.id, text="Оценка добавлена")
            sc_menu = types.InlineKeyboardMarkup()
            sc_menu.add(types.InlineKeyboardButton(text='\U0001F519 Назад', callback_data='add_score_ch'))
            with open(str(call.from_user.id) + '_' + str(subject_name[0]) + '.txt', 'r', encoding='UTF-8') as f_m:
                informatics = f_m.readlines()

            answer = ''
            for i in informatics:
                answer += ' ' + i

            bot.send_message(call.message.chat.id, 'Список оценок:\n' + answer, reply_markup=sc_menu)
            bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id,
                                          reply_markup=None)  # удаляем кнопки после ответа
        elif subject_name[1] == 'math':  # Добавление оценок
            with open(str(call.from_user.id) + '_' + str(subject_name[0]) + '.txt', 'r', encoding='UTF-8') as f_m:
                informatics = f_m.readlines()

            informatics.append(call.data + "\n")

            with open(str(call.from_user.id) + '_' + str(subject_name[0]) + '.txt', 'w', encoding='UTF-8') as f_m:
                f_m.writelines(informatics)

            bot.answer_callback_query(call.id, text="Оценка добавлена")
            sc_menu = types.InlineKeyboardMarkup()
            sc_menu.add(types.InlineKeyboardButton(text='\U0001F519 Назад', callback_data='add_score_ch'))
            with open(str(call.from_user.id) + '_' + str(subject_name[0]) + '.txt', 'r', encoding='UTF-8') as f_m:
                informatics = f_m.readlines()

            answer = ''
            for i in informatics:
                answer += ' ' + i

            bot.send_message(call.message.chat.id, 'Список оценок:\n' + answer, reply_markup=sc_menu)
            bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id,
                                          reply_markup=None)  # удаляем кнопки после ответа


bot.polling(none_stop=True, interval=0)
