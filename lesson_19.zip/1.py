
import telebot
from telebot import types

token = '6706497732:AAF3gVQ58t-COXOeStmxo8DqvBF_OERtEyk'
bot = telebot.TeleBot(token)


@bot.message_handler(commands=['start'])
def start_message(message):
    keyboard = telebot.types.ReplyKeyboardMarkup(True)
    keyboard.row('Привет', 'Пока')
    bot.send_message(message.chat.id, 'Привет!', reply_markup=keyboard)


@bot.message_handler(commands=['test'])
def start_message(message):
    markup = telebot.types.InlineKeyboardMarkup()
    markup.add(telebot.types.InlineKeyboardButton(text='Плохо', callback_data=3))
    markup.add(telebot.types.InlineKeyboardButton(text='Хорошо', callback_data=4))
    markup.add(telebot.types.InlineKeyboardButton(text='Отлично', callback_data=5))
    bot.send_message(message.chat.id, text="Как у тебя дела?", reply_markup=markup)


@bot.callback_query_handler(func=lambda call: True)
def query_handler(call):
    bot.answer_callback_query(callback_query_id=call.id, text='Спасибо за честный ответ!')
    answer = ''
    if call.data == '3':
        answer = 'Не грусти!'
    elif call.data == '4':
        answer = 'Рад, что у тебя всё хорошо!'
    elif call.data == '5':
        answer = 'Рад, что у тебя всё отлично!'
    bot.send_message(call.message.chat.id, text=answer)
    bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id)

bot.polling(none_stop=True, interval=0)
