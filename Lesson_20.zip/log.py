from pyowm.owm import OWM
owm = OWM('5cfab280c5a91c0fe493c1beb57a8b0a') # СЮДА ВСТАВИТЬ ТОКЕН (Можно оставить этот, если работает)

reg = owm.city_id_registry()
mgr = owm.weather_manager()
#part 1
orig_city = 'Samara'
c_country ='RU'
list_of_locations = reg.locations_for(orig_city, country= c_country)#получение координат по названию

print(list_of_locations)

coor_city = list_of_locations[0]
lat_m = coor_city.lat
lon_m = coor_city.lon
print(lat_m,lon_m)
#part 2

one_call = mgr.one_call(lat=lat_m, lon=lon_m, units='metric')#запрос сейчас
print('Погода сейчаc: ')
print(one_call.current.status)  # например, облачно, дождь, снег
print(one_call.current.detailed_status) # подробнее, насколько облачно
temp_m = one_call.current.temperature().get('temp') # текущая температура
print(temp_m)


days=int(input(('Выберите прогноз на +(0-7) дней: '))) # запрос на 0-7 дней
print(one_call.forecast_daily[days].detailed_status) # например, облачно, дождь, снег
print('Темература утром: ',one_call.forecast_daily[days].temperature().get('feels_like_morn', None))
print('Темература днем: ',one_call.forecast_daily[days].temperature().get('feels_like_day', None))
print('Темература вечером: ',one_call.forecast_daily[days].temperature().get('feels_like_eve', None))
print('Темература ночью: ',one_call.forecast_daily[days].temperature().get('feels_like_night', None))