
import telebot
from telebot import types
import pyowm
from googletrans import Translator



bot = telebot.TeleBot('')
translator = Translator()
owm=pyowm.OWM('5cfab280c5a91c0fe493c1beb57a8b0a')
config_dict = owm.configuration
config_dict['language'] = 'ru'


def w_flag_check(call,flag):
    with open(str(call.from_user.id) + '_flag' + '.txt', 'w', encoding='UTF-8') as f_m:
        f_m.write(flag)


def r_flag_check(call):
    flag_name=''
    with open(str(call.from_user.id) + '_flag' + '.txt', 'r', encoding='UTF-8') as f_m:
                flag_name = f_m.read().split('\n')
    return flag_name

def w_ch_country(call,country):
        with open(str(call.from_user.id) + '_country_choice' + '.txt', 'w', encoding='UTF-8') as f_m:
                f_m.write(country)

def r_ch_country(call):
    with open(str(call.from_user.id) + '_country_choice' + '.txt', 'r', encoding='UTF-8') as f_m:
                country_name = f_m.read().split('\n')
    return country_name

def w_ch_city(call,city):
    input_city = str(city).capitalize()
    result = translator.translate(input_city, src='ru', dest='en')#перевод города
    orig_city = result.text

    with open(str(call.from_user.id) + '_city_choice' + '.txt', 'w', encoding='UTF-8') as f_m:
            f_m.write(orig_city)

def r_ch_city(call):
    with open(str(call.from_user.id) + '_city_choice' + '.txt', 'r', encoding='UTF-8') as f_m:
                city_name = f_m.read().split('\n')
    return city_name

def w_lon_lat(call):
    co_ch = r_ch_country(call)
    ci_ch = r_ch_city(call)
    list_of_locations = reg.locations_for(str(ci_ch[0]), country=str(co_ch[0]) )#получение координат по названию
    print(list_of_locations)
    if len(list_of_locations) > 0:
        coor_city = list_of_locations[0]
        lat1 = coor_city.lat
        lon1 = coor_city.lon
        print(lat1,lon1)
        with open(str(call.from_user.id) + '_longitude' + '.txt', 'w', encoding='UTF-8') as f_m:
            f_m.write(str(lon1))
        with open(str(call.from_user.id) + '_latitude' + '.txt', 'w', encoding='UTF-8') as f_m:
            f_m.write(str(lat1))
        w_flag_check(call,'')
    else:
        bot.send_message(call.chat.id, 'Город не найден, попробуй еще раз')
        with open(str(call.from_user.id) + '_longitude' + '.txt', 'w', encoding='UTF-8') as f_m:
            f_m.write('')
        with open(str(call.from_user.id) + '_latitude' + '.txt', 'w', encoding='UTF-8') as f_m:
            f_m.write('')

def r_longitude(call):
    with open(str(call.from_user.id) + '_longitude' + '.txt', 'r', encoding='UTF-8') as f_m:
                cur_longitude = f_m.read().split('\n')
    return cur_longitude[0]

def r_latitude(call):
    with open(str(call.from_user.id) + '_latitude' + '.txt', 'r', encoding='UTF-8') as f_m:
                cur_latitude = f_m.read().split('\n')
    return cur_latitude[0]



@bot.message_handler(commands=['start'])
def wchoose_country(message):
    ch_country = types.InlineKeyboardMarkup() #сохраняем разметку клавиатуры в переменную
    ch_country.add(types.InlineKeyboardButton("Россия", callback_data="RU"))
    bot.send_message(message.chat.id, 'Выберите страну', reply_markup= ch_country)


@bot.message_handler(content_types='text')
def check(message):
    global reg,mgr,owm

    mgr = owm.weather_manager()
    reg = owm.city_id_registry()
    print(message)
    rfch = r_flag_check(message)
    print('rfch',rfch)
    if rfch[0] == 'flag':
        w_ch_city(message,message.text)
        choice = r_ch_city(message)
        w_lon_lat(message)
        if r_longitude(message) != '':
            bot.send_message(message.chat.id, 'Город выбран: '+ str(choice[0]))
            ch_weather = types.InlineKeyboardMarkup() #сохраняем разметку клавиатуры в переменную
            ch_weather.row_width = 2
            ch_weather.add(types.InlineKeyboardButton("Сейчас", callback_data="now"), types.InlineKeyboardButton("На +1 день", callback_data="add_day_1"))
            ch_weather.add( types.InlineKeyboardButton("На +2 дня", callback_data="add_day_2"), types.InlineKeyboardButton("На +3 дня", callback_data="add_day_3"))
            ch_weather.add( types.InlineKeyboardButton("На +4 дня", callback_data="add_day_4"),  types.InlineKeyboardButton("На +5 дней", callback_data="add_day_5"))
            ch_weather.add( types.InlineKeyboardButton("На +6 дней", callback_data="add_day_6"),  types.InlineKeyboardButton("На +7 дней", callback_data="add_day_7"))
            bot.send_message(message.chat.id, 'Выберите тип прогноза ', reply_markup= ch_weather)

    else:
        bot.send_message(message.chat.id, 'Повторите ввод')





@bot.callback_query_handler(func=lambda call: True)
def query_handler(call):

    if call.data == 'main_menu':
        ch_country = types.InlineKeyboardMarkup()
        ch_country.add(types.InlineKeyboardButton("Россия", callback_data="RU"))
        bot.send_message(call.message.chat.id, 'Выберите страну', reply_markup= ch_country)

        bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id, reply_markup = None)
        bot.answer_callback_query(call.id, text="")

    elif call.data == 'RU':
        w_ch_country(call,'RU')
        w_flag_check(call,'flag')
        ch_city = types.InlineKeyboardMarkup()
        ch_city.add(types.InlineKeyboardButton("Назад", callback_data="main_menu"))
        bot.send_message(call.message.chat.id, 'Введите название города: ',reply_markup= ch_city)

        bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id, reply_markup = None)
        bot.answer_callback_query(call.id, text="")


    elif call.data == 'weather':
        ch_weather = types.InlineKeyboardMarkup() #сохраняем разметку клавиатуры в переменную
        ch_weather.row_width = 2
        ch_weather.add(types.InlineKeyboardButton("Сейчас", callback_data="now"), types.InlineKeyboardButton("На +1 день", callback_data="add_day_1"))
        ch_weather.add( types.InlineKeyboardButton("На +2 дня", callback_data="add_day_2"), types.InlineKeyboardButton("На +3 дня", callback_data="add_day_3"))
        ch_weather.add( types.InlineKeyboardButton("На +4 дня", callback_data="add_day_4"),  types.InlineKeyboardButton("На +5 дней", callback_data="add_day_5"))
        ch_weather.add( types.InlineKeyboardButton("На +6 дней", callback_data="add_day_6"),  types.InlineKeyboardButton("На +7 дней", callback_data="add_day_7"))
        ch_weather.add( types.InlineKeyboardButton("Назад", callback_data="main_menu"))
        bot.send_message(call.message.chat.id, 'Выберите тип прогноза ', reply_markup= ch_weather)

        bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id, reply_markup = None)
        bot.answer_callback_query(call.id, text="")

    elif call.data == 'now':
        lon1=float(r_longitude(call))
        lat1=float(r_latitude(call))
        one_call = mgr.one_call(lat=lat1, lon=lon1, units='metric')
        back_menu = types.InlineKeyboardMarkup()
        back_menu.add(types.InlineKeyboardButton("Назад", callback_data="weather"))
        bot.send_message(call.message.chat.id, 'Погода сейчас:   '+ str(one_call.current.detailed_status) +'\n' + 'Температура: ' + str(one_call.current.temperature().get('temp'))+ ' \U00002103', reply_markup= back_menu)

        bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id, reply_markup = None)
        bot.answer_callback_query(call.id, text="")


    elif call.data == 'add_day_1':
        days=int(call.data[-1])
        print(days)
        lon1=float(r_longitude(call))
        lat1=float(r_latitude(call))

        one_call = mgr.one_call(lat=lat1, lon=lon1, units='metric')
        back_menu = types.InlineKeyboardMarkup()
        back_menu.add(types.InlineKeyboardButton("Назад", callback_data="weather"))
        bot.send_message(call.message.chat.id, 'Погода через +' +str(days) +' день: ' + str(one_call.forecast_daily[days].detailed_status) + '\n' + 'Темература утром: ' + str(one_call.forecast_daily[days].temperature().get('feels_like_morn', None)) + ' \U00002103' +'\n' + 'Темература днем: ' + str(one_call.forecast_daily[days].temperature().get('feels_like_day', None)) + ' \U00002103' +'\n' + 'Темература вечером: '+ str(one_call.forecast_daily[days].temperature().get('feels_like_eve', None)) + ' \U00002103' +'\n' + 'Темература ночью: ' + str(one_call.forecast_daily[days].temperature().get('feels_like_night', None)) + ' \U00002103', reply_markup= back_menu)
        bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id, reply_markup = None)
        bot.answer_callback_query(call.id, text="")

    elif call.data == 'add_day_2':
        days=int(call.data[-1])
        print(days)
        lon1=float(r_longitude(call))
        lat1=float(r_latitude(call))

        one_call = mgr.one_call(lat=lat1, lon=lon1, units='metric')
        back_menu = types.InlineKeyboardMarkup()
        back_menu.add(types.InlineKeyboardButton("Назад", callback_data="weather"))
        bot.send_message(call.message.chat.id, 'Погода через +' +str(days) +' дня: ' + str(one_call.forecast_daily[days].detailed_status) + '\n' + 'Темература утром: ' + str(one_call.forecast_daily[days].temperature().get('feels_like_morn', None)) + ' \U00002103' +'\n' + 'Темература днем: ' + str(one_call.forecast_daily[days].temperature().get('feels_like_day', None)) + ' \U00002103' +'\n' + 'Темература вечером: '+ str(one_call.forecast_daily[days].temperature().get('feels_like_eve', None)) + ' \U00002103' +'\n' + 'Темература ночью: ' + str(one_call.forecast_daily[days].temperature().get('feels_like_night', None)) + ' \U00002103', reply_markup= back_menu)

        bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id, reply_markup = None)
        bot.answer_callback_query(call.id, text="")

    elif call.data == 'add_day_3':
        days=int(call.data[-1])
        print(days)
        lon1=float(r_longitude(call))
        lat1=float(r_latitude(call))

        one_call = mgr.one_call(lat=lat1, lon=lon1, units='metric')
        back_menu = types.InlineKeyboardMarkup()
        back_menu.add(types.InlineKeyboardButton("Назад", callback_data="weather"))
        bot.send_message(call.message.chat.id, 'Погода через +' +str(days) +' дня: ' + str(one_call.forecast_daily[days].detailed_status) + '\n' + 'Темература утром: ' + str(one_call.forecast_daily[days].temperature().get('feels_like_morn', None)) + ' \U00002103' +'\n' + 'Темература днем: ' + str(one_call.forecast_daily[days].temperature().get('feels_like_day', None)) + ' \U00002103' +'\n' + 'Темература вечером: '+ str(one_call.forecast_daily[days].temperature().get('feels_like_eve', None)) + ' \U00002103' +'\n' + 'Темература ночью: ' + str(one_call.forecast_daily[days].temperature().get('feels_like_night', None)) + ' \U00002103', reply_markup= back_menu)

        bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id, reply_markup = None)
        bot.answer_callback_query(call.id, text="")

    elif call.data == 'add_day_4':
        days=int(call.data[-1])
        print(days)
        lon1=float(r_longitude(call))
        lat1=float(r_latitude(call))

        one_call = mgr.one_call(lat=lat1, lon=lon1, units='metric')
        back_menu = types.InlineKeyboardMarkup()
        back_menu.add(types.InlineKeyboardButton("Назад", callback_data="weather"))
        bot.send_message(call.message.chat.id, 'Погода через +' +str(days) +' дня: ' + str(one_call.forecast_daily[days].detailed_status) + '\n' + 'Темература утром: ' + str(one_call.forecast_daily[days].temperature().get('feels_like_morn', None)) + ' \U00002103' +'\n' + 'Темература днем: ' + str(one_call.forecast_daily[days].temperature().get('feels_like_day', None)) + ' \U00002103' +'\n' + 'Темература вечером: '+ str(one_call.forecast_daily[days].temperature().get('feels_like_eve', None)) + ' \U00002103' +'\n' + 'Темература ночью: ' + str(one_call.forecast_daily[days].temperature().get('feels_like_night', None)) + ' \U00002103', reply_markup= back_menu)

        bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id, reply_markup = None)
        bot.answer_callback_query(call.id, text="")

    elif call.data == 'add_day_5':
        days=int(call.data[-1])
        print(days)
        lon1=float(r_longitude(call))
        lat1=float(r_latitude(call))

        one_call = mgr.one_call(lat=lat1, lon=lon1, units='metric')
        back_menu = types.InlineKeyboardMarkup()
        back_menu.add(types.InlineKeyboardButton("Назад", callback_data="weather"))
        bot.send_message(call.message.chat.id, 'Погода через +' +str(days) +' дней: ' + str(one_call.forecast_daily[days].detailed_status) + '\n' + 'Темература утром: ' + str(one_call.forecast_daily[days].temperature().get('feels_like_morn', None)) + ' \U00002103' +'\n' + 'Темература днем: ' + str(one_call.forecast_daily[days].temperature().get('feels_like_day', None)) + ' \U00002103' +'\n' + 'Темература вечером: '+ str(one_call.forecast_daily[days].temperature().get('feels_like_eve', None)) + ' \U00002103' +'\n' + 'Темература ночью: ' + str(one_call.forecast_daily[days].temperature().get('feels_like_night', None)) + ' \U00002103', reply_markup= back_menu)
        bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id, reply_markup = None)
        bot.answer_callback_query(call.id, text="")

    elif call.data == 'add_day_6':
        days=int(call.data[-1])
        print(days)
        lon1=float(r_longitude(call))
        lat1=float(r_latitude(call))

        one_call = mgr.one_call(lat=lat1, lon=lon1, units='metric')
        back_menu = types.InlineKeyboardMarkup()
        back_menu.add(types.InlineKeyboardButton("Назад", callback_data="weather"))
        bot.send_message(call.message.chat.id, 'Погода через +' +str(days) +' дней: ' + str(one_call.forecast_daily[days].detailed_status) + '\n' + 'Темература утром: ' + str(one_call.forecast_daily[days].temperature().get('feels_like_morn', None)) + ' \U00002103' +'\n' + 'Темература днем: ' + str(one_call.forecast_daily[days].temperature().get('feels_like_day', None)) + ' \U00002103' +'\n' + 'Темература вечером: '+ str(one_call.forecast_daily[days].temperature().get('feels_like_eve', None)) + ' \U00002103' +'\n' + 'Темература ночью: ' + str(one_call.forecast_daily[days].temperature().get('feels_like_night', None)) + ' \U00002103', reply_markup= back_menu)

        bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id, reply_markup = None)
        bot.answer_callback_query(call.id, text="")

    elif call.data == 'add_day_7':
        days=int(call.data[-1])
        print(days)
        lon1=float(r_longitude(call))
        lat1=float(r_latitude(call))

        one_call = mgr.one_call(lat=lat1, lon=lon1, units='metric')
        back_menu = types.InlineKeyboardMarkup()
        back_menu.add(types.InlineKeyboardButton("Назад", callback_data="weather"))
        bot.send_message(call.message.chat.id, 'Погода через +' +str(days) +' дней: ' + str(one_call.forecast_daily[days].detailed_status) + '\n' + 'Темература утром: ' + str(one_call.forecast_daily[days].temperature().get('feels_like_morn', None)) + ' \U00002103' +'\n' + 'Темература днем: ' + str(one_call.forecast_daily[days].temperature().get('feels_like_day', None)) + ' \U00002103' +'\n' + 'Темература вечером: '+ str(one_call.forecast_daily[days].temperature().get('feels_like_eve', None)) + ' \U00002103' +'\n' + 'Темература ночью: ' + str(one_call.forecast_daily[days].temperature().get('feels_like_night', None)) + ' \U00002103', reply_markup= back_menu)

        bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id, reply_markup = None)
        bot.answer_callback_query(call.id, text="")

bot.polling(none_stop=True,interval=0)