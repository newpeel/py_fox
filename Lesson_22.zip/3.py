# pip install PyMultiDictionary
import telebot
from telebot import types
from googletrans import Translator

from PyMultiDictionary import MultiDictionary

dictionary = MultiDictionary()

bot = telebot.TeleBot('6706497732:AAF3gVQ58t-COXOeStmxo8DqvBF_OERtEyk')
translator = Translator()


@bot.message_handler(commands=['start'])
def start(message):
    bot.send_message(message.chat.id,
                     'Привет! Отправь любое слово, я переведу его на английский и расскажу что оно значит!')


@bot.message_handler(content_types='text')
def start(message):
    word = translator.translate(message.text, src='ru', dest='en')

    temp = dictionary.meaning('en', word.text)
    temp2 = temp[0]
    word_type = ", ".join(temp2)
    main_mean = str(temp[1])
    add_mean = ', '.join(str(x) for x in temp[2:])

    temp = dictionary.synonym('en', word.text)
    syn_mean = ", ".join(temp[0:4])

    temp = dictionary.antonym('en', word.text)
    ant_mean = ", ".join(temp[0:4])

    print('Тип: ', word_type)
    print('Определение: ', main_mean)
    print('Комментарии: ', add_mean)
    print('синонимы: ', syn_mean)
    print('антонимы: ', ant_mean)

    bot.send_message(message.chat.id, message.text.capitalize() + ' переводится как ' + word.text)
    bot.send_message(message.chat.id, message.text.capitalize() + ' является: ' + word_type)
    bot.send_message(message.chat.id, 'Определение ' + word.text + ': \n' + main_mean)
    bot.send_message(message.chat.id, 'Дополнительные комментарии: \n' + add_mean)
    bot.send_message(message.chat.id, 'Синонимы: ' + syn_mean)
    bot.send_message(message.chat.id, 'Антонимы: ' + ant_mean)


print(1)
bot.polling(none_stop=True)
