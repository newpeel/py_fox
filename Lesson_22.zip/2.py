from PyMultiDictionary import MultiDictionary

dictionary = MultiDictionary()

word = input()

temp = dictionary.meaning('en', word)
print(temp)

temp = dictionary.meaning('en', word)
temp2 = temp[0]
word_type = ", ".join(temp2)
temp = dictionary.meaning('ru', word)
main_mean = str(temp[1])  # основное значение

# комментарии
add_mean = ', '.join(str(x) for x in temp[2:])
temp = dictionary.synonym('en', word)
syn_mean = ", ".join(temp[0:4])

temp = dictionary.antonym('en', word)
ant_mean = ", ".join(temp[0:4])

print('Тип: ', word_type)
print('Определение: ', main_mean)
print('Комментарии: ', add_mean)
print('синонимы: ', syn_mean)
print('антонимы: ', ant_mean)
