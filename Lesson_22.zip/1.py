import telebot
from telebot import types
from googletrans import Translator

bot = telebot.TeleBot('6706497732:AAF3gVQ58t-COXOeStmxo8DqvBF_OERtEyk')

translator = Translator()

@bot.message_handler(commands=['start'])
def start(message):
    bot.send_message(message.chat.id,'Привет! Отправь любой текст, и я его переведу его на английский!')

@bot.message_handler(content_types='text')
def start(message):
    word = translator.translate(message.text, src='ru', dest='en')

    bot.send_message(message.chat.id,message.text + ' переводится как ' + word.text)

print(1)
bot.polling(none_stop = True)

