import pygame


pygame.init()

#создаем окно
screen = pygame.display.set_mode((800, 600))
pygame.display.set_caption("Моя первая игра")

#главный цикл программы, в нем происходит отслеживание событий приложения и действий пользователя
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                print('sp')
        # Обработка нажатия клавиши пробел
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                print('lb')
        # Обработка нажатия левой кнопки мыши

#завершаем работу игры
pygame.quit()
