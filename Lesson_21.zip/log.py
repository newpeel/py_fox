from gtts import gTTS
import telebot
from telebot import types
import pyowm
from googletrans import Translator

owm = pyowm.OWM('1b9c5e8a4611727e8b1c9a876ccd3ef4')
bot = telebot.TeleBot('')
translator = Translator()
config_dict = owm.configuration
config_dict['language'] = 'ru'


def w_language(call, text):
    with open(str(call.from_user.id) + '_lang' + '.txt', 'w', encoding='UTF-8') as f_m:
        f_m.write(str(text))


def r_language(call):
    with open(str(call.from_user.id) + '_lang' + '.txt', 'r', encoding='UTF-8') as f_m:
        lang_ch = f_m.read().split('\n')
    return lang_ch[0]


@bot.message_handler(commands=['start'])
def start(message):
    w_language(message, 'ru')
    bot.send_message(message.chat.id,
                     'Привет! Отправь любой текст, и я его озвучу! \n Чтобы узнать погоду, напиши !город \n /language чтобы поменять язык')
    a_res = gTTS(text='Привет, я люблю котиков', lang='ru', slow=False)
    a_res.save(str(message.from_user.id) + '.mp3')
    with open(str(message.from_user.id) + '.mp3', 'rb') as a_f:
        audio = a_f.read()
    bot.send_audio(message.chat.id, audio)


@bot.message_handler(commands=['language'])
def l_ch(message):
    ch_lan = types.InlineKeyboardMarkup()
    ch_lan.add(types.InlineKeyboardButton("RU", callback_data="ru"),
               types.InlineKeyboardButton("EN", callback_data="en"))
    bot.send_message(message.chat.id, 'Выберите язык', reply_markup=ch_lan)


@bot.message_handler(content_types=['text'])
def answer(message):
    mgr = owm.weather_manager()
    reg = owm.city_id_registry()

    if message.text[0] == '!':
        rcity = message.text[1:]
        rcity = rcity.capitalize()

        new_city = translator.translate(rcity, src='ru', dest='en')
        rlang = 'ru'
        rcountry = 'RU'

        list_of_locations = reg.locations_for(new_city.text, country=rcountry)
        coor_city = list_of_locations[0]
        lat_m = coor_city.lat
        lon_m = coor_city.lon

        one_call = mgr.one_call(lat=lat_m, lon=lon_m, units='metric')
        st_now = one_call.current.detailed_status
        temp_now = one_call.current.temperature().get('temp')
        description = 'Сейчас в локации ' + message.text[1:] + ' ' + st_now + ' и температура ' + str(temp_now)
        bot.send_message(message.chat.id, description)

        a_res = gTTS(text=description, lang=rlang, slow=False)
        a_res.save(str(message.from_user.id) + '.mp3')
        with open(str(message.from_user.id) + '.mp3', 'rb') as a_f:
            audio = a_f.read()
        bot.send_audio(message.chat.id, audio)

    else:
        mytext = message.text
        rlang = r_language(message)
        a_res = gTTS(text=mytext, lang=rlang, slow=False)
        a_res.save(str(message.from_user.id) + '.mp3')
        with open(str(message.from_user.id) + '.mp3', 'rb') as a_f:
            audio = a_f.read()
        bot.send_audio(message.chat.id, audio)


@bot.callback_query_handler(func=lambda call: True)
def query_handler(call):
    if call.data == 'ru':
        w_language(call, 'ru')
        bot.answer_callback_query(call.id, text="Выбран русский язык")
        bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id, reply_markup=None)

    elif call.data == 'en':
        w_language(call, 'en')
        bot.answer_callback_query(call.id, text="Выбран английский язык")
        bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id, reply_markup=None)


bot.polling(none_stop=True)