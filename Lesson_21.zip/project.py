from gtts import gTTS
import telebot
from telebot import types

bot = telebot.TeleBot('')


def w_language(call, text):
    with open(str(call.from_user.id) + '_lang' + '.txt', 'w', encoding='UTF-8') as f_m:
        f_m.write(str(text))


def r_language(call):
    with open(str(call.from_user.id) + '_lang' + '.txt', 'r', encoding='UTF-8') as f_m:
        lang_ch = f_m.read().split('\n')
    return lang_ch[0]


@bot.message_handler(commands=['start'])
def start(message):
    w_language(message, 'ru')
    bot.send_message(message.chat.id, 'Привет! Отправь любой текст, и я его озвучу!')
    a_result = gTTS(text='Привет, я люблю котиков', lang='ru', slow=False)
    a_result.save("result.mp3")
    with open('result.mp3', 'rb') as a_f:
        audio = a_f.read()
    bot.send_audio(message.chat.id, audio)


@bot.message_handler(commands=['language'])
def lan_ch(message):
    ch_lan = types.InlineKeyboardMarkup()
    ch_lan.add(types.InlineKeyboardButton("RU", callback_data="ru"),
               types.InlineKeyboardButton("EN", callback_data="en"))
    bot.send_message(message.chat.id, 'Выберите язык', reply_markup=ch_lan)


@bot.callback_query_handler(func=lambda call: True)
def query_handler(call):
    if call.data == 'ru':
        w_language(call, 'ru')
        bot.answer_callback_query(call.id, text="Выбран русский язык")
        bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id, reply_markup=None)
    elif call.data == 'en':
        w_language(call, 'en')
        bot.answer_callback_query(call.id, text="Выбран английский язык")
        bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id, reply_markup=None)


@bot.message_handler(content_types=['text'])
def answer(message):
    mytext = message.text
    rlang = r_language(message)
    myobj = gTTS(text=mytext, lang=rlang, slow=False)
    myobj.save("result.mp3")
    with open('result.mp3', 'rb') as a_f:  # mp3 содержит бинарную информацию, поэтому открываем через rb
        audio = a_f.read()
    bot.send_audio(message.chat.id, audio)


bot.polling(none_stop=True)
