import telebot

token = '6706497732:AAF3gVQ58t-COXOeStmxo8DqvBF_OERtEyk'

bot = telebot.TeleBot(token)


@bot.message_handler(content_types=["text"])
def repeat_all_messages(message):
    bot.send_message(message.chat.id, message.text)


bot.polling(none_stop=True, interval=0)


