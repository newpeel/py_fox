import telebot
from service import token, questions, multi1, multi2, multi3, multi4, correctAnswer, valueWon

bot = telebot.TeleBot(token)

ansr = None
x = 0
check = ''


@bot.message_handler(commands=["reset"])
def controls(message):
    global x
    global check
    global score
    global ansr
    ansr = None
    x = 0
    check = ''
    bot.send_message(message.chat.id, "Отправь 1 чтобы начать")
    # bot.send_message(message.chat.id, str(message.message_id))
    # print(message.text)


@bot.message_handler(content_types=["text"])
def game(message):
    global x
    global check
    global score

    ansr = str.upper(message.text)  # с компьютера и телефона одинаково удобно

    print(message)
    print(message.text)

    if (
            ansr == 'A' or ansr == 'B' or ansr == 'C' or ansr == 'D') and x < 14:  # and message.message_id != check:   #message.caption можно проверить , перевод в uppercase

        if ansr == correctAnswer[x]:
            bot.send_message(message.chat.id, 'Правильно')
            x += 1
            bot.send_message(message.chat.id, 'Текущий счет ' + str(valueWon[x]))
            bot.send_message(message.chat.id, str(
                questions[x] + '\n' + multi1[x] + '\n' + multi2[x] + '\n' + multi3[x] + '\n' + multi4[x] + '\n'))
        else:
            bot.send_message(message.chat.id, 'Неправильно. Игра начинается заново')
            bot.send_message(message.chat.id, 'Финальный счет ' + str(valueWon[x]))
            x = 0
            bot.send_message(message.chat.id, "Отправь 1 чтобы начать")


    elif (ansr == 'A' or ansr == 'B' or ansr == 'C' or ansr == 'D') and x == 14:

        if ansr == correctAnswer[x]:
            bot.send_message(message.chat.id, 'Победа!')
            bot.send_message(message.chat.id, 'Финальный счет ' + str(valueWon[x + 1]))
        else:
            bot.send_message(message.chat.id, 'Неправильно. Игра начинается заново')
            bot.send_message(message.chat.id, 'Финальный счет ' + str(valueWon[x]))
            x = 0

    else:
        bot.send_message(message.chat.id, str(
            questions[x] + '\n' + multi1[x] + '\n' + multi2[x] + '\n' + multi3[x] + '\n' + multi4[x] + '\n'))


bot.polling(none_stop=True,
            interval=0)  # Она скажет программе, чтобы она непрерывно спрашивала у бота, не пришли ли ему какие-то новые сообщения
